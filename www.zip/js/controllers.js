angular.module('starter.controllers', [])



.controller('DashCtrl', function ($scope) { })

.controller('SearchCtrl', function ($scope) {

 })


.controller('LikeCtrl', function ($scope) {

})




.controller('AccountCtrl', function ($scope) {

    function MyCtrl($scope, $ionicTabsDelegate) {
  $scope.selectTabWithIndex = function(index) {
    $ionicTabsDelegate.select(index);
  }
}

});
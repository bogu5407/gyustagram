angular.module('starter.controllers', [])



.controller('DashCtrl', function ($scope) { })



.controller('ChatsCtrl', function ($scope, Chats) {

})

.controller('MyCtrl',function ($scope,$ionicTabsDelegate ){

})



.controller('AccountCtrl', function ($scope) {

    function MyCtrl($scope, $ionicTabsDelegate) {
  $scope.selectTabWithIndex = function(index) {
    $ionicTabsDelegate.select(index);
  }
}

});